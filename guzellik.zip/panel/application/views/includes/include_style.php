<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bower/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.css">
<!-- build:css /assets/css/app.min.css -->
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bower/animate.css/animate.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bower/fullcalendar/dist/fullcalendar.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bower/perfect-scrollbar/css/perfect-scrollbar.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/core.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/app.css">
<!-- endbuild -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">

<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/iziToast.min.css">

<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/custom.css">
<script src="<?php echo base_url("assets"); ?>/libs/bower/breakpoints.js/dist/breakpoints.min.js"></script>
<script>
    Breakpoints();
</script>