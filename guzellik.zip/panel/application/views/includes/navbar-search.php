<div class="abc mo"><a target="_blank" href="<?php echo "https://" . $_SERVER['SERVER_NAME']; ?>"> <button type="submit" class="btn  btn-inverse">Siteye Git</button></a>

    </button></div>

<style>

    .abc{
position: relative;
        float: right;
        margin-top: -50px;
        margin-right: 30px;
        z-index: 2000;
    }
</style>
<style>

    @media (max-width: 767px) {
        .mo {
            display: none !important;
        }
    }
    @media (min-width: 767px) {
        .ma {
            display: none !important;
        }
    }

</style>