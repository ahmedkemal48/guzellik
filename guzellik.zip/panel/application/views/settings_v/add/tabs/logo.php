<div role="tabpanel" class="tab-pane fade" id="tab-7">

    <div class="row">

        <div class="form-group col-md-6">
            <label>Masaüstü Logo Seçimi</label>
            <input type="file" name="logo" class="form-control">
        </div>

    </div>
    <div class="row">

        <div class="form-group col-md-6">
            <label>Admin Logo Seçimi</label>
            <input type="file" name="admin_logo" class="form-control">
        </div>

    </div>

    <div class="row">

        <div class="form-group col-md-6">
            <label>Mobil Logo Seçimi</label>
            <input type="file" name="mobile_logo" class="form-control">
        </div>

    </div>

    <div class="row">

        <div class="form-group col-md-6">
            <label>Favicon Seçimi</label>
            <input type="file" name="favicon" class="form-control">
        </div>

    </div>

</div><!-- .tab-pane  -->